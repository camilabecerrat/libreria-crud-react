import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { addBook, updateBook, getBookById } from "../services/booksLocalService";

const initialState = {
  title: "",
  author: "Yuval Noah Harari",
  publishedYear: "",
  image: "",
  description: "",
};

export default function BookForm() {
  const navigate = useNavigate();
  const { id } = useParams();
  const editing = Boolean(id);

  const [form, setForm] = useState(initialState);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editing) {
      const book = getBookById(id);
      if (book) setForm(book);
      else navigate("/");
    }
  }, [id, editing, navigate]);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  }

  function validate() {
    let errs = {};
    if (!form.title.trim()) errs.title = "El título es requerido";
    if (!form.author.trim()) errs.author = "El autor es requerido";
    if (form.publishedYear && isNaN(form.publishedYear))
      errs.publishedYear = "El año debe ser numérico";
    return errs;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }
    if (editing) {
      updateBook(id, form);
    } else {
      addBook(form);
    }
    navigate("/");
  }

  return (
    <div className="form-container">
      <h2>{editing ? "Editar Libro" : "Agregar Libro"}</h2>
      <form onSubmit={handleSubmit} className="book-form">
        <label>
          Título *
          <input
            name="title"
            value={form.title}
            onChange={handleChange}
            required
            autoFocus
          />
          {errors.title && <span className="error">{errors.title}</span>}
        </label>
        <label>
          Autor *
          <input
            name="author"
            value={form.author}
            onChange={handleChange}
            required
            disabled
          />
          {errors.author && <span className="error">{errors.author}</span>}
        </label>
        <label>
          Año de publicación
          <input
            name="publishedYear"
            value={form.publishedYear}
            onChange={handleChange}
            type="number"
            min="0"
            placeholder="Ej: 2014"
          />
          {errors.publishedYear && (
            <span className="error">{errors.publishedYear}</span>
          )}
        </label>
        <label>
          URL de la imagen
          <input
            name="image"
            value={form.image}
            onChange={handleChange}
            placeholder="https://..."
          />
        </label>
        <label>
          Descripción
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
          />
        </label>
        <div className="form-actions">
          <button type="submit">{editing ? "Guardar" : "Agregar"}</button>
          <button type="button" onClick={() => navigate("/")}>
            Cancelar
          </button>
        </div>
      </form>
    </div>
  );
}