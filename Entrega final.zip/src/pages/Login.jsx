import React, { useContext, useState } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function Login() {
  const { user, login } = useContext(AuthContext);
  const navigate = useNavigate();

  const [form, setForm] = useState({ username: "", password: "" });
  const [error, setError] = useState("");

  if (user) return <Navigate to="/" />;

  function handleChange(e) {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  }

  function handleSubmit(e) {
    e.preventDefault();
    const ok = login(form.username, form.password);
    if (ok) {
      navigate("/");
    } else {
      setError("Credenciales incorrectas. Prueba otra vez.");
    }
  }

  return (
    <div className="form-container">
      <h2>Iniciar Sesión</h2>
      <form onSubmit={handleSubmit} className="book-form">
        <label>
          Usuario
          <input
            name="username"
            value={form.username}
            onChange={handleChange}
            required
            autoFocus
          />
        </label>
        <label>
          Contraseña
          <input
            name="password"
            type="password"
            value={form.password}
            onChange={handleChange}
            required
          />
        </label>
        {error && <span className="error">{error}</span>}
        <div className="form-actions">
          <button type="submit">Ingresar</button>
        </div>
      </form>
      <div style={{ marginTop: "1rem", color: "#555" }}>
        <b>Prueba como:</b>
        <ul>
          <li>admin / admin123 (admin)</li>
          <li>user / user123 (usuario común)</li>
        </ul>
      </div>
    </div>
  );
}