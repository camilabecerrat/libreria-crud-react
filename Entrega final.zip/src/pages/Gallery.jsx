import React, { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import { getBooks, deleteBook } from "../services/booksLocalService";
import BookCard from "../components/BookCard";
import { AuthContext } from "../context/AuthContext";

export default function Gallery() {
  const [books, setBooks] = useState([]);
  const { user } = useContext(AuthContext);

  useEffect(() => {
    setBooks(getBooks());
  }, []);

  function handleDelete(id) {
    if (window.confirm("¿Seguro que deseas eliminar este libro?")) {
      deleteBook(id);
      setBooks(getBooks());
    }
  }

  return (
    <main>
      <div className="gallery-header">
        <h1>Librería: Yuval Noah Harari</h1>
        {user?.role === "admin" && (
          <Link to="/add">
            <button>Agregar libro</button>
          </Link>
        )}
      </div>
      <div className="gallery-grid">
        {books.length === 0 ? (
          <p>No hay libros registrados.</p>
        ) : (
          books.map((book) => (
            <BookCard key={book.id} book={book} onDelete={handleDelete} />
          ))
        )}
      </div>
    </main>
  );
}