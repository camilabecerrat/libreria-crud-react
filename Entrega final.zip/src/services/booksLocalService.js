import { v4 as uuidv4 } from "uuid";

const STORAGE_KEY = "books";

export function getBooks() {
  return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
}

export function addBook(book) {
  const books = getBooks();
  const newBook = { ...book, id: uuidv4() };
  localStorage.setItem(STORAGE_KEY, JSON.stringify([...books, newBook]));
  return newBook;
}

export function updateBook(id, updated) {
  const books = getBooks().map((b) => (b.id === id ? { ...b, ...updated } : b));
  localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
}

export function deleteBook(id) {
  const books = getBooks().filter((b) => b.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
}

export function getBookById(id) {
  return getBooks().find((b) => b.id === id);
}