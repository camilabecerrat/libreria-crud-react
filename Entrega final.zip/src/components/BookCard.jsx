import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function BookCard({ book, onDelete }) {
  const { user } = useContext(AuthContext);

  return (
    <div className="book-card">
      <img
        src={
          book.image ||
          "https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg"
        }
        alt={book.title}
        className="book-cover"
      />
      <div className="book-info">
        <h3>{book.title}</h3>
        <p>
          <b>Autor:</b> {book.author}
        </p>
        {book.publishedYear && (
          <p>
            <b>Año:</b> {book.publishedYear}
          </p>
        )}
        {book.description && <p>{book.description}</p>}
        {user?.role === "admin" && (
          <div className="book-actions">
            <Link to={`/edit/${book.id}`}>
              <button>Editar</button>
            </Link>
            <button onClick={() => onDelete(book.id)} className="danger">
              Eliminar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}