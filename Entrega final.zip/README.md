# Librería CRUD con React + Vite

## Requisitos
- Node.js 18+
- npm

## Instalación
```bash
npm install